* License: GPL v3
* Authors: Zhang Huangbin (zhb _at_ iredmail.org)

* Check whether this is the lastest version:
  [Download the latest iRedMail](http://www.iredmail.org/download.html)

* Install iRedMail by following our installation guides strictly:
  [Installation Guides](http://www.iredmail.org/docs/)

* Community, bug report, feature requests:
  [online support forum](https://forum.iredmail.org/)

* [Paid support service](http://www.iredmail.org/support.html)

* Source packages patched or modified for RHEL/CentOS can be download here:
  [http://www.iredmail.org/yum/srpms/](http://www.iredmail.org/yum/srpms/)
  Other packages not listed in above directory are all fetched from EPEL
  repository: [http://fedoraproject.org/wiki/EPEL](http://fedoraproject.org/wiki/EPEL)
